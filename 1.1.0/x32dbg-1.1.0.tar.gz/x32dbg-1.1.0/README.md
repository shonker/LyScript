An automated testing plugin developed for the x32dbg debugger, used to quickly build Python based test scripts to accelerate the development of exploit programs, assist in vulnerability mining, and analyze malware.

Copyright (c) 2009-2024 LyShark <me@lyshark.com>

All rights reserved.

For detailed copyright information see the file COPYING in the root of the distribution archive.